using System;
using System.Web;
using System.Web.UI;

namespace SHAB.Presentation
{
	public partial class shgn_ta_op_ILUS_TREE_CHANNEL  : SHMA.CodeVision.Presentation.TabBase
	{
	}
}



