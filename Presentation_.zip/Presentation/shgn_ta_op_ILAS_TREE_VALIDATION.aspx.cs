using System;
using System.Web;
using System.Web.UI;

namespace SHAB.Presentation
{
	public partial class shgn_ta_op_ILAS_TREE_VALIDATION  : SHMA.CodeVision.Presentation.TabBase
	{
	}
}



