using System;

namespace SHAB.Presentation {
	public partial class PolicyAcceptance_Button : SHMA.CodeVision.Presentation.ButtonbarBase{
 
	}
}

