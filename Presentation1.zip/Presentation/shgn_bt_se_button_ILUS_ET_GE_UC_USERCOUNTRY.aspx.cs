using System;

namespace SHAB.Presentation {
	public partial class shgn_bt_se_button_ILUS_ET_GE_UC_USERCOUNTRY : SHMA.CodeVision.Presentation.ButtonbarBase{
 
	}
}

